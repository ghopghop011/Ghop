# Photo Overlay (Android project)

A starter Android app that lets you select an image from the Android photo picker and display it as a draggable floating overlay only while standard WhatsApp (`com.whatsapp`) is detected in the foreground.

## Build from an Android phone using GitHub Actions

This project includes `.github/workflows/build-apk.yml` so you can build it in GitHub's cloud from a mobile browser:

1. Sign in to GitHub in your phone browser and create a **new private repository**.
2. Upload the contents of this project folder to the repository (keep the `.github/workflows/build-apk.yml` file and its folders).
3. Open the repository's **Actions** tab and select **Build Photo Overlay APK**.
4. Tap **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run, scroll to **Artifacts**, and download `PhotoOverlay-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.

You can also use the Android app or browser's file picker to upload the project files. If GitHub's mobile layout hides the Actions tab, open the browser menu and request the desktop site.

## Build on a computer

Open this folder in Android Studio, sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Setup on phone

1. Install the APK.
2. Open Photo Overlay and choose a photo.
3. Grant **Display over other apps** permission.
4. Grant **Usage access** so the app can detect which app is in the foreground.
5. Press **Start WhatsApp overlay**.
6. Drag the photo to reposition it. Change size and transparency in the app.

## Limitations

- The allow-list is only standard WhatsApp (`com.whatsapp`), not WhatsApp Business.
- The service polls Usage Access events and removes the overlay when WhatsApp is not foregrounded. A short transition delay is possible.
- Android vendors may stop background services. Auto-start after reboot is best-effort; battery and OS restrictions may prevent it.
- Android may show a persistent foreground-service notification while enabled.
- This is starter code and has not yet been compiled or device-tested. Review and test it on your phone before relying on it.
