package com.example.photooverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView

class OverlayService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var image: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var lastPackage: String? = null
    private var lastX = 0f
    private var lastY = 0f
    private val prefs by lazy { getSharedPreferences("overlay", Context.MODE_PRIVATE) }
    private val poll = object : Runnable {
        override fun run() {
            if (!prefs.getBoolean("enabled", false)) { stopSelf(); return }
            val foreground = foregroundPackage()
            if (foreground == "com.whatsapp") showOverlay() else hideOverlay()
            handler.postDelayed(this, 650)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(72, makeNotification())
        handler.post(poll)
    }

    private fun makeNotification(): Notification {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("photo_overlay", "Photo Overlay", NotificationManager.IMPORTANCE_LOW))
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "photo_overlay") else Notification.Builder(this)
        return builder.setContentTitle("Photo Overlay is active")
            .setContentText("The selected photo appears only over WhatsApp")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true).build()
    }

    private fun foregroundPackage(): String? {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 5000, end)
        val event = UsageEvents.Event()
        var current: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND || event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) current = event.packageName
        }
        return current
    }

    private fun showOverlay() {
        if (image != null || !Settings.canDrawOverlays(this)) return
        val uri = prefs.getString("photoUri", null)?.let(Uri::parse) ?: return
        val view = ImageView(this).apply {
            setImageURI(uri)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = prefs.getInt("alpha", 100) / 100f
            setBackgroundColor(0x00000000)
            setOnTouchListener(DragTouchListener())
        }
        val size = prefs.getInt("sizeDp", 180)
        val lp = WindowManager.LayoutParams(
            (size * resources.displayMetrics.density).toInt(),
            (size * resources.displayMetrics.density).toInt(),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", 40); y = prefs.getInt("y", 180) }
        try { wm.addView(view, lp); image = view; params = lp } catch (_: Exception) { image = null; params = null }
    }

    private fun hideOverlay() {
        val v = image ?: return
        try { wm.removeView(v) } catch (_: Exception) {}
        image = null; params = null
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = params ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; return true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt(); lp.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> { prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply(); return true }
            }
            return false
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        hideOverlay()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
