package com.example.photooverlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("overlay", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false) || prefs.getString("photoUri", null) == null) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            val service = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service)
        } catch (_: Exception) {
            // Android may block background service starts; user can reopen the app to resume.
        }
    }
}
