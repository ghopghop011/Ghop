package com.example.photooverlay

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overlay", Context.MODE_PRIVATE) }
    private lateinit var photoStatus: TextView
    private lateinit var permissionStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::permissionStatus.isInitialized) refreshStatus()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            root.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 })
        }
        root.addView(TextView(this).apply {
            text = "Photo Overlay"
            textSize = 27f
            setTextColor(0xFF128C7E.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Choose a photo to show as a movable overlay only while WhatsApp is open."
            textSize = 16f
            setPadding(0, 12, 0, 12)
        })
        photoStatus = TextView(this).apply { textSize = 14f }
        root.addView(photoStatus)
        button("Choose photo from gallery") { choosePhoto() }
        button("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("Allow usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        permissionStatus = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 4) }
        root.addView(permissionStatus)
        root.addView(TextView(this).apply { text = "Overlay size"; textSize = 15f; setPadding(0, 14, 0, 0) })
        root.addView(SeekBar(this).apply {
            max = 280
            progress = (prefs.getInt("sizeDp", 180) - 80).coerceIn(0, 280)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { prefs.edit().putInt("sizeDp", progress + 80).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        root.addView(TextView(this).apply { text = "Transparency"; textSize = 15f; setPadding(0, 8, 0, 0) })
        root.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("alpha", 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { prefs.edit().putInt("alpha", progress.coerceAtLeast(10)).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        button("Start WhatsApp overlay") { startOverlay() }
        button("Stop overlay") { stopService(Intent(this, OverlayService::class.java)); prefs.edit().putBoolean("enabled", false).apply(); Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show() }
        root.addView(TextView(this).apply {
            text = "When active, the photo is shown only over the WhatsApp app (com.whatsapp). Drag it to move it. Android may pause background services or auto-start depending on phone settings."
            textSize = 12f
            setPadding(0, 18, 0, 0)
        })
        setContentView(root)
        refreshStatus()
    }

    private fun choosePhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Deprecated by platform; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("photoUri", uri.toString()).apply()
            refreshStatus()
        }
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshStatus() {
        val selected = prefs.getString("photoUri", null)
        photoStatus.text = if (selected == null) "No photo selected" else "Photo selected ✓"
        val overlay = Settings.canDrawOverlays(this)
        val usage = hasUsageAccess()
        permissionStatus.text = "Overlay permission: ${if (overlay) "OK" else "needed"}\nWhatsApp detection access: ${if (usage) "OK" else "needed"}"
    }

    private fun startOverlay() {
        if (prefs.getString("photoUri", null) == null) { Toast.makeText(this, "Choose a photo first", Toast.LENGTH_SHORT).show(); return }
        if (!Settings.canDrawOverlays(this) || !hasUsageAccess()) { Toast.makeText(this, "Grant both permissions first", Toast.LENGTH_LONG).show(); refreshStatus(); return }
        prefs.edit().putBoolean("enabled", true).apply()
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, OverlayService::class.java))
            else startService(Intent(this, OverlayService::class.java))
        } catch (e: Exception) { Toast.makeText(this, "Could not start. Open the app and try again.", Toast.LENGTH_LONG).show() }
    }
}
